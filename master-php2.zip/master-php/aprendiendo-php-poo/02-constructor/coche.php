<?php

// Programacion Orientada a Objetos en PHP (POO)

/*
 * Definir una clase (molde para crear más objetos de tipo coche con características parecidas)
 */
class Coche{
    
// Atributos o propiedades (variables)
public $color;
public $marca;
public $modelo;
public $velocidad;
public $caballaje;
public $plazas;

// Constructor
public function __construct($color,$marca,$modelo,$velocidad,$caballaje,$plazas) {
$this->color = $color;
$this->marca = $marca;
$this->modelo = $modelo;
$this->velocidad = $velocidad;
$this->caballaje = $caballaje;
$this->plazas = $plazas;
}

// Metodos, son acciones que hace el objeto (antes funciones)
public function getColor(){
    // Busca en esta clase la propiedad X
    return $this->color;
}

public function setColor($color){
    $this->color = $color;
}   

public function acelerar(){
    $this->velocidad++;
}

public function frenar(){
    $this->velocidad--;
}

public function getVelocidad(){
    return $this->velocidad;
}

// Tipado
public function infoCoche(Coche $miObjeto){
    $informacion = '<h2>Informacion del coche:</h2> ';
    $informacion .= 'Color: '.$miObjeto->color;
    $informacion .= '<br/> Modelo: '.$miObjeto->modelo;
    $informacion .= '<br/> Velocidad: '.$miObjeto->velocidad;
    return $informacion;
}


} // fin definicion de la clase


