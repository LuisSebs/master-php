<?php
require_once 'coche.php';

$coche = new Coche("Amarillo", "Renauld", "Clio", 150, 200, 5);

var_dump($coche);

echo $coche->infoCoche($coche);

?>