<?php

// Programacion Orientada a Objetos en PHP (POO)

/*
 * Definir una clase (molde para crear más objetos de tipo coche con características parecidas)
 */
class Coche{
    
// Atributos o propiedades (variables)
    
public $color = "rojo";
public $marca = "toyota";
public $modelo = "avanza";
public $velocidad = 0;
public $caballaje = "4 caballos";
public $plazas = "Ecatepec";

// Metodos, son acciones que hace el objeto (antes funciones)
public function getColor(){
    // Busca en esta clase la propiedad X
    return $this->color;
}

public function setColor($color){
    $this->color = $color;
}   

public function acelerar(){
    $this->velocidad++;
}

public function frenar(){
    $this->velocidad--;
}

public function getVelocidad(){
    return $this->velocidad;
}

} // fin definicion de la clase

// Crear un objeto / instanciar la clase
$coche = new Coche();

// Usar los metodos

$coche->setColor("Amarillo");
echo 'El color del coche es: '.$coche->getColor();
echo '<br/>';

echo 'La velocidad del coche es: '.$coche->getVelocidad();
echo '<br/>';


$coche->acelerar();
$coche->acelerar();
$coche->acelerar();
$coche->acelerar();
$coche->acelerar();
$coche->frenar();

echo 'La velocidad del coche es: '.$coche->getVelocidad();
echo '<br/>';


// Otro objeto (coche)

$coche2 = new Coche();
