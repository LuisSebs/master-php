<?php
// Conectar a la base de datos
$hostname = "localhost";
$username = "root";
$password = "";
$database = "phpmysql";
$conexion = mysqli_connect($hostname, $username, $password, $database,);

// Comprobar si la conexion es la correcta
if(mysqli_connect_errno()){
    echo "La conexion a la base de datos MySQL ha fallado: ".mysqli_connect_error();
}else{
    echo "Conexion realizada correctamente!";
}

// Consulta para configurar la codificacion de caracteres
mysqli_query($conexion, "SET NAMES 'utf8'");

// Consulta SELECT desde PHP
$consulta = mysqli_query($conexion, "SELECT * FROM notas");

// Recorrer todas los registros con un array asociativo
while($nota = mysqli_fetch_assoc($consulta)){
    var_dump($nota);
}

// Insertar en la base de datos desde PHP
$sql = "INSERT INTO notas VALUES (null, 'Nota desde PHP', 'Esto es una nota de PHP', 'green')";
$insert = mysqli_query($conexion, $sql);

if($insert){
    echo "DATOS INSERTADOS CORRECTAMENTE";
}else{
    echo "Error: ".mysqli_error($conexion);
}
 


