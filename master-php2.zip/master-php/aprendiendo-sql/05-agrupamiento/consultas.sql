# CONSULTAS AGRUPAMIENTO
# SELECT columna FROM tabla GROUP BY columna;

# Obtener la cantidad de registros
# SELECT COUNT(columna) AS '<nombre alias>' FROM tabla GROUP BY columna;

# Consultas de agrupamiento con condicion
SELECT COUNT(columna) AS '<nombre alias>' 
FROM tabla GROUP BY columna HAVING condicion;

# FUNCIONES DE AGRUPAMIENTO
/*
AVG         Sacar la media
COUNT       Contar el numero de elementos
MAX         Valor maximo del grupo
MIN         Valor minimo del grupo
SUM         Sumar todo el contenido del grupo
*/
