/*
Vistas: 
Las podemos definir como una consulta almacenada en la base de datos
que se utiliza como una tabla virtual. No almacena datos sino que utiliza asociaciones
y los datos originales de las tablas, de forma que siempre se mantiene actualizada.
*/

# EJEMPLO:
CREATE VIEW entradas_con_nombres AS 
SELECT * FROM tabla;

