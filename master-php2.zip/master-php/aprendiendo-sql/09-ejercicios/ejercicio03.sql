/*
Incrementar el precio de los coches en un dos porciento.
*/

UPDATE coches SET precio = (precio) + (precio * 0.02);