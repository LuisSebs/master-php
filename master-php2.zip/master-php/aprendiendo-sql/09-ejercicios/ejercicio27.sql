
/*
27. Visualizar los nombres de los clientes y la cantidad de encargos realizados,
incluyendo los que no hayan realizado encargos
*/

# Insertamos un cliente de prueba para visualizar los que no han hecho encargos
INSERT INTO clientes VALUES(NULL,5,'Tienda Organica Inc', 'Murcia', 0, CURDATE());

# Visualizamos la cantidad de encargos que ha realizado cada cliente con encargos
SELECT e.cliente_id, c.nombre, COUNT(e.id) AS 'ENCARGOS' FROM encargos e
INNER JOIN clientes c ON c.id  = e.cliente_id  GROUP BY cliente_id;

# Visualizamos la cantidad de encargos que ha realizado cada cliente incluyendo los que no han realizado encargos
SELECT e.cliente_id, c.nombre, COUNT(e.id) AS 'ENCARGOS' FROM encargos e
RIGHT JOIN clientes c ON c.id  = e.cliente_id  GROUP BY cliente_id;
