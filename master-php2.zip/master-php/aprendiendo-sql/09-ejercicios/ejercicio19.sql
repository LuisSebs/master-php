/*
19. Obtener los vendedores que con 2 o mas clientes
*/

# Visualizamos el id del vendedor y la cantidad de clientes de cada uno
SELECT vendedor_id, COUNT(id) FROM clientes GROUP BY (vendedor_id);

# Visualizamos los que tienen mas de dos clientes
SELECT vendedor_id, COUNT(id) FROM clientes GROUP BY (vendedor_id) HAVING COUNT(id) > 2;

# Obtenemos unicamente el id de los vendedorres
SELECT vendedor_id FROM clientes GROUP BY (vendedor_id) HAVING COUNT(id) > 2;

# Visualizamos los vendedores con mas de dos clientes
SELECT * FROM vendedores  WHERE id IN 
(SELECT vendedor_id FROM clientes GROUP BY (vendedor_id) HAVING COUNT(id) > 2);