/*
24. Listar los encargos con el nombre del coche, el nombre del cliente y
el nombre de la ciudad, pero unicamente cuando sean de Barcelona.
*/

# Mi consulta
SELECT co.modelo, c.nombre, c.ciudad FROM encargos e
INNER JOIN clientes c ON e.cliente_id = c.id
INNER JOIN coches co ON e.coche_id = co.id WHERE ciudad = 'Barcelona';
