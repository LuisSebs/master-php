/*
25. Obtener una lista de los nombres de los clientes con el importe 
de sus ecargos acumulado
*/

SELECT ci.nombre, SUM(precio*cantidad) AS 'IMPORTE'
FROM clientes ci
INNER JOIN encargos e ON ci.id = e.cliente_id
INNER JOIN coches co ON co.id = e.coche_id GROUP BY e.cliente_id;
