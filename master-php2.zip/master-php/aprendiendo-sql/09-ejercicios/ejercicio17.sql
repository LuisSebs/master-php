/*
17. Obtener listado con los encargos realizados por el cliente 'Fruteria Antonia Inc' 
*/

# El id del cliente 'Fruteria Antonia Inc'
SELECT id FROM clientes WHERE nombre = 'Fruteria Antonia Inc';

# Revisamos cuantos encargos tiene ese id
SELECT * FROM encargos WHERE cliente_id IN (SELECT id FROM clientes WHERE nombre = 'Fruteria Antonia Inc');