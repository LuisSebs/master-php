
/*
20. Seleccionar el grupo en el que trabaja el vendedor con mayor sueldo
y mostrar el nombre del grupo
*/

# Mi consulta que no funciono
# SELECT id, nombre FROM grupos WHERE id IN (SELECT grupo_id FROM vendedores ORDER BY sueldo DESC LIMIT 1);


# Mi consulta que si funciono
# Obtenemos el id del grupo al que pertenece el vendedor con mayor sueldo
SELECT grupo_id FROM vendedores ORDER BY sueldo DESC LIMIT 1
# Obtenemos el id y nombre del grupo
SELECT id, nombre FROM grupos WHERE id = (SELECT grupo_id FROM vendedores ORDER BY sueldo DESC LIMIT 1);

# Consulta mostrada en el curso:
SELECT * FROM grupos WHERE id IN
(SELECT grupo_id FROM vendedores WHERE sueldo =
(SELECT MAX(sueldo) FROM vendedores));