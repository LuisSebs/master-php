/*
16. Obtener un listado de clientes atendidos por el vendedor 'David Lopez';
*/

# Obtenemos el id del cliente 'David Lopez';

SELECT id FROM vendedores WHERE CONCAT(nombre, ' ', apellidos)  = 'David Lopez';

# Buscamos los clientes que han sido atendidos por el id de 'David Lopez';

 SELECT * FROM clientes WHERE vendedor_id = (SELECT id FROM vendedores WHERE CONCAT(nombre, ' ', apellidos)  = 'David Lopez');

/*
NOTA: Es recomendable usar IN en vez del igual =
*/

SELECT * FROM clientes WHERE vendedor_id IN (SELECT id FROM vendedores WHERE CONCAT(nombre, ' ', apellidos)  = 'David Lopez');

