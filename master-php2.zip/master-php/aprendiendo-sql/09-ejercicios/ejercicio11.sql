/*
11. Visualizar todos los cargos y el numero de vendedores que hay en cada cargo
*/

SELECT DISTINCT cargo, COUNT(id) AS 'Cantidad de puestos ocupados' FROM vendedores GROUP BY cargo;
