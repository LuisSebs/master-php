/*
15. Mostrar los primeros 3 clientes que mas pedidos han hecho y mostrar cuantos pedidos hicieron.
*/

/*
NOTA: Con el NATURAL JOIN no tenemos que especificar los campos que queremos
que coincidan, automaticamente toma las llaves primarias y foraneas de las tablas
y hace el match. En cambio con el INNER JOIN si especificamos.
*/

SELECT cliente_id, nombre, COUNT(id) FROM encargos NATURAL JOIN clientes GROUP BY cliente_id ORDER BY COUNT(id) DESC LIMIT 3;

/*
NOTA: Otra forma de usar la sentencia ORDER BY es pasandole como
parametro el indice de los campos que especificaste en la sentencia 
SELECT. 

POR EJEMPLO: La sentencia de arriba podemos especificarla tambien de la siguiente manera:
*/

SELECT cliente_id, nombre, COUNT(id) FROM encargos NATURAL JOIN clientes GROUP BY cliente_id ORDER BY 3 DESC LIMIT 3;

/*Estamos especificando que ordene por la 3ra columna que especificamos en SELECT,
es decir la columna COUNT(id).
*/

