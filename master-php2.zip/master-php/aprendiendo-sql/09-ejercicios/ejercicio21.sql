/*
21. Obtener los nombres y ciudades de los clientes con encargos de 3 unidades en adelante.
*/

# Obtenemos los clientes que han realizado encargos
SELECT * FROM clientes WHERE id IN 
(SELECT cliente_id FROM encargos);

# Tomamos en cuenta solo los que tienen mas de 3 encargos
SELECT nombre, ciudad FROM clientes WHERE id IN 
(SELECT cliente_id FROM encargos WHERE cantidad >= 3);