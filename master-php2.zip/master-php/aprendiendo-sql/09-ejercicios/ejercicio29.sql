/*
29. Crear una vista llamada vendedoresA que incluira todos los vendedores
del grupo que se llame "Vendedores A"
*/

# Obtenemos la lista de vendedores que pertenecen al grupo 'Vendedores A' FORMA1
SELECT v.id, CONCAT(v.nombre,' ',v.apellidos) AS 'VENDEDORES', v.grupo_id
FROM vendedores v
INNER JOIN grupos g
ON g.id = v.grupo_id
WHERE g.nombre = 'Vendedores A';

# Obtenemos la lista de vendedores que pertenecen al grupo 'Vendedores A' FORMA2 (Usaremos la forma 2, la del curso)

# Obtenemos el id de los grupos con nombre 'Vendedores A'
SELECT id FROM grupos WHERE nombre = 'Vendedores A';

# Buscamos los vendedores donde su grupo_id sea perteneciente a los grupos con nombre 'Vendedores A'
SELECT * FROM vendedores WHERE grupo_id IN
(SELECT id FROM grupos WHERE nombre = 'Vendedores A');

# Creamos la vista
CREATE VIEW vendedoresA AS
SELECT * FROM vendedores WHERE grupo_id IN
(SELECT id FROM grupos WHERE nombre = 'Vendedores A');



