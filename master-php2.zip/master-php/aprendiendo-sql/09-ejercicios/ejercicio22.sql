/*
22. Mostrar listado de clientes (numero de cliente y el nombre)
mostrar tambien el numero de vendedor y su nombre
*/

# Mi consulta
SELECT clientes.id, 
clientes.nombre AS 'Cliente', 
vendedores.id, 
CONCAT(vendedores.nombre, ' ', vendedores.apellidos) AS 'Vendedor' 
FROM clientes INNER JOIN vendedores ON clientes.vendedor_id = vendedores.id;

# Consulta que hacen en el curso
SELECT c.id, c.nombre, v.id, CONCAT(v.nombre, ' ', v.apellidos) AS 'VENDEDOR'
FROM clientes c, vendedores v
WHERE c.vendedor_id = v.id;
