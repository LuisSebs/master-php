/*
18. Listar los clientes que han hecho algun encargo del coche 'Mercedes Ranchera'
*/

# Mi consulta que no funciono
# select clientes.id, clientes.nombre, modelo from clientes NATURAL JOIN encargos NATURAL JOIN coches WHERE modelo = 'Mercedes Ranchera';

# Mi consulta que funciono
select clientes.id, clientes.nombre, encargos.id from (clientes NATURAL JOIN encargos NATURAL JOIN coches) 
WHERE coche_id IN (SELECT id FROM coches WHERE modelo = 'Mercedes Ranchera');

# Obtenemos el id del coche 'Mercedes Ranchera'
SELECT id FROM coches WHERE modelo LIKE '%Mercedes Ranchera%';

# Obtenemos el id de los clientes que han hecho el cargo del coche 'Mercedes Ranchera'
SELECT cliente_id FROM encargos WHERE coche_id IN 
(SELECT id FROM coches WHERE modelo LIKE '%Mercedes Ranchera%');

# Obtenemos la informacion de los clientes que han hecho el encargo del coche 'Mercedes Ranchera'
SELECT * FROM clientes WHERE id IN 
(SELECT cliente_id FROM encargos WHERE coche_id IN 
(SELECT id FROM coches WHERE modelo LIKE '%Mercedes Ranchera%'));