/*
26. Sacar los vendedores que tienen jefe y sacar el nombre del jefe.
*/

# Forma 1 CON INNER JOIN
SELECT v.nombre AS 'Vendedor', j.nombre AS 'Jefe' FROM vendedores v
INNER JOIN vendedores j ON v.jefe = j.id;

# Forma 2 SIN INNER JOIN
SELECT v.nombre AS 'Vendedor', j.nombre AS 'Jefe'  FROM vendedores v, vendedores j
WHERE v.jefe = j.id;

 