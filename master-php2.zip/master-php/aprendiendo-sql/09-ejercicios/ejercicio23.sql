/*
23. Listar todos los encargos realizados con la marca del coche y el nombre
del cliente.
*/

# Mi consulta
SELECT e.id, co.marca, c.nombre
FROM encargos e, coches co, clientes c
WHERE e.cliente_id = c.id AND e.coche_id = co.id;

# Consulta que hacen el curso
SELECT e.id, co.marca, c.nombre FROM encargos e
INNER JOIN coches co ON co.id = e.coche_id
INNER JOIN clientes c ON c.id = e.cliente_id;