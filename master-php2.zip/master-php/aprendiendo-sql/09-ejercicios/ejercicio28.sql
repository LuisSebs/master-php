/*
28. Mostrar todos los vendedores y el numero de clientes.
Se deben mostrar tengan o no clientes
*/

# Visualizamos los vendedores que tengan clientes
SELECT DISTINCT v.id, CONCAT(v.nombre, ' ', v.apellidos) AS 'VENDEDOR' FROM vendedores v
INNER JOIN clientes c ON c.vendedor_id = v.id;

# Incluimos los vendedores que no tienen clientes
SELECT DISTINCT v.id, CONCAT(v.nombre, ' ', v.apellidos) AS 'VENDEDOR' FROM vendedores v
LEFT JOIN clientes c ON c.vendedor_id = v.id;

# Agregamos la cantidad de clientes de cada vendedor
SELECT v.id, CONCAT(v.nombre, ' ', v.apellidos) AS 'VENDEDOR', COUNT(c.id) 
FROM vendedores v
LEFT JOIN clientes c ON c.vendedor_id = v.id 
GROUP BY v.id;

