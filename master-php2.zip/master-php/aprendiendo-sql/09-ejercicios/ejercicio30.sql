/*
30. Mostrar los datos del vendedor con mas antiguedad en el concesionario.
*/


/*
NOTA: Al ordenar por fecha de manera descendente (DESC) considera
la fecha mas vieja como la menor y la mas reciente como la mayor.
*/


SELECT * FROM vendedores ORDER BY fecha ASC LIMIT 1;


# 30.1. Obtener los coches con mas unidades vendidas

# Obtenemos la cantidad de unidades vendidas por cada coche
SELECT coche_id, SUM(cantidad) 
FROM encargos GROUP BY coche_id;

# Obtenemos el id del coche con mas unidades vendidas
SELECT coche_id 
FROM encargos GROUP BY coche_id ORDER BY SUM(cantidad) DESC LIMIT 1;

# Obtenemos la informacion del coche con mas unidades vendidas
SELECT * FROM coches WHERE id =
(SELECT coche_id 
FROM encargos 
GROUP BY coche_id 
ORDER BY SUM(cantidad) DESC LIMIT 1);

/*
NOTA:

Cuando en una subconsulta x usamos LIMIT, AN, ALL, ANY, SOME y 
en la consulta principal utilizamos SELECT ... FROM ... WHERE <campo> IN x
aparece el siguiente mensaje:


This version of MySQL doesn't yet support 'LIMIT & IN/ALL/ANY/SOME subquery'

Para resolver esto, cambiamos el IN de la consulta principal
por un igual =

SELECT ... FROM ... WHERE <campo> = x

ESTO SOLO SI EL RESULTADO DE x ES UNICAMENTE
UN resultado.

*/

