/*
13. Sacar la media de sueldos entre todos los vendedores por grupo.
*/

SELECT grupo_id , AVG(sueldo) AS 'Media salarial' FROM vendedores GROUP BY grupo_id;

/*
13.1 Sacar la media de sueldos entre todos los vendedores por grupo (mostrar nombre del grupo).
*/

SELECT grupos.nombre , AVG(sueldo) AS 'Media salarial' FROM vendedores INNER JOIN grupos ON vendedores.grupo_id = grupos.id GROUP BY grupo_id;

/*
13.2 Sacar la media de sueldos entre todos los vendedores por grupo (mostrar nombre del grupo) y mostrar la ciudad.
*/

SELECT ciudad, grupos.nombre , AVG(sueldo) AS 'Media salarial' FROM vendedores INNER JOIN grupos ON vendedores.grupo_id = grupos.id GROUP BY grupo_id;

/*
13.3 Sacar la media de sueldos entre todos los vendedores por grupo (mostrar nombre del grupo) y mostrar la ciudad, limitar el promedio a 2 decimas
*/

SELECT ciudad, grupos.nombre , ROUND(AVG(sueldo),2) AS 'Media salarial' FROM vendedores INNER JOIN grupos ON vendedores.grupo_id = grupos.id GROUP BY grupo_id;