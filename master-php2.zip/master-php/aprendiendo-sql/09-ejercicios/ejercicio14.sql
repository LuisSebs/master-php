/*
14. Visualizar las unidades totales vendidas de cada coche a cada cliente.
*/

SELECT coches.modelo AS 'Coche', clientes.nombre AS 'Cliente', SUM(cantidad) AS 'Unidades' FROM encargos 
INNER JOIN coches ON coches.id = encargos.coche_id 
INNER JOIN clientes ON clientes.id = encargos.cliente_id
GROUP BY encargos.coche_id, encargos.cliente_id;