/*
TIPOS:
int                         ENTERO
integer                     ENTERO
varchar()                   STRING (MAX 255 CARACTERES)
char()                      STRING 
float                       DECIMAL
date,time,timestamp         FECHA

// STRINGS MAS GRANDES
TEXT
MEDIUMTEXT
LONGTEXT

// ENTEROS MAS GRANDES
MEDIUMINT
BIBGINT
*/

/*
CREAR TABLA
*/

CREATE TABLE usuario(
    id      int(11),
    nombre  varchar(100),
    apellidos varchar(255),
    email varchar(100),
    password varchar(100)
);