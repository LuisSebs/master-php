/*
SUBCONSULTAS:
- Son consultas que se ejecutan dentro de otras.
- Consiste en utilizar los resultados d ela subconsulta para operar en la consulta principal
- Jugando con las claves ajenas / foraneas.
*/

# EJEMPLO
# SELECT * FROM tabla where columna IN (SELECT columna FROM tabla)
/*
Notemos que hacemos una consulta principal que es la de
SELECT columna FROM table; y tenemos una segunda subconsulta
que se deriva de la primera, esta es SELECT *FROM tabla WHERE columna IN (consula principal).
*/
  
