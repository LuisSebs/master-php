# BORRAR REGISTROS
# Borrar registros especificos
# DELETE FROM tabla  WHERE columna = <valor>;