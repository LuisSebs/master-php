# MODIFICAR FILAS / ACTUALIZAR DATOS

# MODIFICAR TODOS LOS REGISTROS
# UPDATE tabla SET columna = <valor>; 

# MODIFICAR REGISTROS ESPECIFICOS
# UPDATE tabla SET columna1 = <valor1>, columna2 = <valor2> WHERE columna = <valor1> and columna2 = <valor2>;
 ; 