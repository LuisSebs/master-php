# Consulta con una condicion
# SELECT * FROM tabla where columna = '<valor>';
/*
OPERADORES DE COMPARACION
igual           =
distinto        !=
menor           <
mayor           >
menor o igual   <=
mayor           o igual >=
entre           betweeen A and B 
en              in
es nulo         is null
#no nulo         is not null
como            like
no es como      not like
*/

/*
OPERADORES LOGICOS
O       OR
Y       AND
NO      NOT
*/

/*
COMODINES:
Cualquier cantidad de caracteres: %
Un caracter desconocido: _
*/
