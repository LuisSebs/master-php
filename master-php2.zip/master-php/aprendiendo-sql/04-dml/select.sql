# Seleccionar filas de una tabla
# SELECT * FROM tabla;
