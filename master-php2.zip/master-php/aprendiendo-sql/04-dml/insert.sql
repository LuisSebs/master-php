# Insertar registros en una tabla

# Forma 1 (llenamos todos los campos/columnas)
# INSERT INTO tabla VALUES(<valor1>, <valor2>,...,<valorN>);

# Forma 2 (especificamos los campos/columnas que queremos llenar)
# INERT INTO  tabla(<campo1>,<campo2>,...,<campoN>) VALUES (<valor1>,<valor2>,...,<valorN>);
