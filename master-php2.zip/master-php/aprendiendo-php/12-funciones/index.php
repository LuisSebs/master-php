<?php
/*
 * FUNCIONES:
 * 
 * function <nombre>(<parametros>){
 *  ...
 * }
 */

// Ejemplo 1
echo '<h3>Ejemplo1: Funcion simple</h3>';
function muestraNombre(){
    echo 'Sebas <br>';
}
muestraNombre(); // Invocamos la funcion

// Ejemplo 2
echo '<h3>Ejemplo2: Funcion con parametros</h3>';
function tabla($numero) {
    echo '<table border="1">';
    for($i = 0; $i<=$numero; $i++){
        // agregamos la columna
        echo '<tr>';
        /*
         * Hacemos esta verificacion
         * para dejar la primera celda
         * vacia e ir formando
         * la PRIMERA COLUMNA
         * con los numeros del 1 al 10
         */
        if($i != 0){
            /*
             * Vamos llenando la primera columna 
             * con los numeros del 1 al 10
             */
            echo '<td>'.$i.'</td>';
        }
        // Llenamos la tabla
        for($j = 1; $j<=10; $j++){
            /*
             * Hacemos esta verificacion
             * para poder crear un espacio
             * en la primera celda de la tabla.
             */
            if($i==0){
              if($i==0 && $j==1){
                // Agregamos el espacio en la primera celda de la tabla
                echo '<td></td>';
              }
              /*
               * Llenamos el resto de la PRIMERA FILA 
               * con los primeros numeros 
               * del 1 al 10
               */
              echo '<td>'.$j.'</td>';  
            }else{
                // Agregamos la multiplicacion de $i con $j
                echo '<td>'.($i * $j).'</td>';
            }
        }
        // cerramos la columna
        echo '</tr>';
    }
    // cerramos la tabla
    echo '</table>';
}

$numero = null;
if(isset($_GET['numero'])){
    $numero = $_GET['numero'];
}else{
    $numero = 10;
}
echo '<h5>Tabla de multiplicar de los primeros '.$numero.' numeros</h5>';
tabla($numero);

// Ejemplo 3
echo '<h3>Ejemplo3: Funcion con parametros opcionales (calculadora)</h3>';
function calculadora($numero1, $numero2, $negrita = false){
    // Conjunto de instrucciones a ejecutar
    if($negrita){
        echo '<strong>';
    }
    
    $suma = $numero1 + $numero2;
    $resta = $numero1 - $numero2;
    $multiplicacion = $numero1 * $numero2;
    $division = $numero1 / $numero2;
    
    echo "Suma: $suma <br>";
    echo "Resta: $resta <br>";
    echo "Multiplicacion: $multiplicacion <br>";
    echo "Division: $division <br>";
    
    if($negrita){
    echo '</strong>';
    }
}
calculadora(10,30);
echo'<hr>';
calculadora(12,55,true);
echo'<hr>';
calculadora(15,32,false);

// Ejemplo 4 (return)
echo '<h3>Ejemplo4: Funcion con retorno (return)</h3>';
function calculadora2($numero1, $numero2, $negrita = false){
    // Conjunto de instrucciones a ejecutar
    $resultado = "";
    if($negrita){
        $resultado .= '<strong>';
    }
    
    $suma = $numero1 + $numero2;
    $resta = $numero1 - $numero2;
    $multiplicacion = $numero1 * $numero2;
    $division = $numero1 / $numero2;
    
    $resultado .= "Suma: $suma <br>";
    $resultado .= "Resta: $resta <br>";
    $resultado .= "Multiplicacion: $multiplicacion <br>";
    $resultado .= "Division: $division <br>";
    
    if($negrita){
    $resultado .= '</strong>';
    }
    
    return $resultado;
}
echo calculadora2(10,30);
echo'<hr>';
echo calculadora2(12,55,true);
echo'<hr>';
echo calculadora2(15,32,false);


// Ejemplo 5
echo '<h3>Ejemplo5: Llamar funciones dentro de otras funciones</h3>';
function getNombre($nombre){
    return 'Tu nombre es: '.$nombre;
}
function getApellido($apellido){
    return 'Tu apellido es: '.$apellido;
}
function nombreCompleto($nombre,$apellido){
    return getNombre($nombre).'<br>'.getApellido($apellido);
}
echo nombreCompleto('Sebastian', 'Arrieta');


?>