<?php
/*
 * Variables locales: Dentro de la funciones. Disponibles dentro de la funcion
 * 
 * Variables globales: Fuera de una funcion. Disponibles fuera y dentro de la funcion
 */

// Variable global 
echo '<h3>Variables globales</h3>';
$frase = ' Ni los genios son tan genios, ni los mediocres tan mediocres';

function holaMundo(){
    global $frase;
    echo $frase;
}
holaMundo();

// FUNCIONES VARIABLES
echo '<h3>Funciones variables ( funciones que pueden invocarse con una variable que contiene el nombre de la funcion como una cadena)</h3>';
function buenosDias(){
    return 'Hola, buenos dias.';
}

function buenasTardes(){
    return 'Hola, buenas tardes,ya comiste?';
}

function buenasNoches(){
    return 'Hola, buenas noches';
}

// Forma de invocarse 1
echo '<h4>Forma de invocarse 1</h4>';
$horario = "buenasNoches";
echo $horario();

// Forma de invocarse 2
echo '<h4>Forma de invocarse 2</h4>';
$tardes = "Tardes";
$forma2 = "buenas".$tardes;
echo $forma2();
        
?>

