<?php
// Debugear
$nombre = "Sebas";
var_dump($nombre);
echo '<br>';

// Fechas
echo date('d-m-y');
echo '<br>';
echo time();

// Matematicas
echo '<br>';
echo "Raiz cuadrada de 10: ".sqrt(10);
echo '<br>';
echo "Numero aleatorio entre 10 y 40: ".rand(10,40);
echo '<br>';
echo "Numero PI: ".pi();
echo '<br>';
echo "Numero PI redondeado con 2 decimales: ".round(pi(),2);
echo '<br>';

// Mas funciones generales
gettype($nombre);
if(is_string($nombre)){
    echo "Esa variables es string";
}
echo '<br>';
if(isset($_GET['nombre'])){
    echo "La variable existe";
}else{
    echo "La varible no existe";
}
echo '<br>';
$frase = "   HOLA   ";
echo trim($frase);

// Eliminar variables / indices
$year = 2020;
unset($year);
var_dump($year);

// Comprobar variable vacia
$texto = ""; 
if(empty($texto)){
    echo "La variable texto esta vacia";
}else{
    echo "La variables texto TIENE CONTENIDO";
}

// Contar caracteres de un string
$texto2 = "Hola";
echo '<br>';
echo strlen($texto2);

// Encontrar caracter
$frase = "La vida es bella";
echo '<br>';
echo strpos($frase,"vida");

// Reemplazar palabras de un string
$frase = str_replace("bella","hermosa",$frase);
echo '<br>';
echo $frase;
echo '<br>'; 

// Mayusculas y minusculas
echo strtolower($frase);
echo '<br>';
echo strtoupper($frase);
echo '<br>';
?>

