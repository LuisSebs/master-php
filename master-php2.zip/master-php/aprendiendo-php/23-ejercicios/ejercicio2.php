<?php
/*
 * Ejercicio 2.
 * 1. Una funcion
 * 2. Validar un email con filter_var
 * 3. Recoger variable por get y validarla
 * 4. Mostrar el resultado
 */
$mensaje = "";
function validar_email($email){
    // Validamos el email
    global $mensaje;
    if(filter_var($email,FILTER_VALIDATE_EMAIL)){
        $mensaje = "El email $email es correcto";
    }else{
        $mensaje = "INTRODUCE UN EMAIL CORRECTO!";
    }
}

if(isset($_GET['email'])){
   $email = $_GET['email'];
   validar_email($email);
   echo "<h1 style='color:red;'>$mensaje</h1>";
}
?>

<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>Ejercicio 2</title>
    </head>
    <body>
        <h1>Validacion de email</h1>
        <form action="ejercicio2.php" method="get">
            <label for="email">Introduce un email</label>
            <p><input type="text" name="email"/></p>
            
            <input type="submit" value="Enviar"/>
        </form>
    </body>
</html>
