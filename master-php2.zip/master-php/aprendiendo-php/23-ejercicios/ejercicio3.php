<?php
/*
 * Ejercicio 3. Hacer una interfaz de usuario(formulario) con dos inputs y 4 botones
 * uno para sumar, restar, dividir y multiplicar.
*/
if(isset($_GET['numero1']) && $_GET['numero2'] && $_GET['op']){
    $n1 = $_GET['numero1'];
    $n2 = $_GET['numero2'];
    switch ($_GET['op']){
        case 'Sumar':
            $resultado = $n1 + $n2;
            break;
        case 'Restar':
            $resultado = $n1 - $n2;
            break;
        case 'Dividir':
            $resultado = $n1 / $n2;
            break;
        case 'Multiplicar':
            $resultado = $n1 * $n2;
            break;
    }
    echo "<h1 style='color:blue;'>El resultado es $resultado</h1>";
}
?>

<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>Ejercicio 3</title>
    </head>
    <body>
        <form action="" method="GET">
            <label for="numero1">Numero 1</label>
            <p><input type="number" name="numero1"/></p>
            <label for="numero2">Numero 2</label>
            <p><input type="number" name="numero2"/></p>
            <input type="submit" value="Sumar" name="op"/>
            <input type="submit" value="Restar" name="op"/>
            <input type="submit" value="Multiplicar" name="op"/>
            <input type="submit" value="Dividir" name="op"/>
        </form>
    </body>
</html>


