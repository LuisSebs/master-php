<?php

// EJEMPLO FOR
// sumar los primeros 100 numeros y regresar el resultado
echo '<h1>Ejemplo for</h1>';
$resultado = 0;
for($i = 0 ; $i <= 100; $i++ ){
    $resultado+=$i;
}
echo "El resultado es: $resultado";

// OTRO EJEMPLO
echo '<h1>Ejemplo for (otra implementacion)</h1>';
$i = 0;
$resultado = 0;
for(;$i <= 100;){
    $resultado += $i;
    $i++;
}
echo "El resultado es: $resultado";
?>

