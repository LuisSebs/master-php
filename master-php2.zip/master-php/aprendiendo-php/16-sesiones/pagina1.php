<?php
session_start();
// Esta variable esta en el fichero index.php y por lo tanto no la puede mostrar
// echo $variable_normal;
// Esta variable la definimos en el fichero index.php pero como es una variable de sesion podemos acceder a ella desde otro fichero
echo $_SESSION['variable_persistente'];
?>

