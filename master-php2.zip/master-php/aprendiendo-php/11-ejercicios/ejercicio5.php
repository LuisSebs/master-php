<?php
/*
 * Ejercicio5. Hacer un programa que muestre todos los numeros entre dos numeros
 * que nos lleguen por la url($_GET).
 */
if(!isset($_GET['numero1'])){
     echo '<p>por favor agrega al final de la url un slash y sun signo de interrogacion <strong>/?</strong>,'
     . ' despues agrega <strong>numero1 = x</strong>, con x el numero que tu quieras seguido de <strong>&</strong>,';
 }
 if(!isset($_GET['numero2'])){
     echo ' despues agrega al final de la url un <strong>numero2 = y</strong>, con y un numero mayor a <strong>x+1</strong>.</p>';
 }
 
 if(isset($_GET['numero1']) && isset($_GET['numero2'])){
     $x = $_GET['numero1'];
     $y = $_GET['numero2'];
     for($i=$x+1;$i<$y;$i++){
         if($i%2==1){
            echo $i.'<br>';   
         }
     }
 }
?>
