<?php
/*
 * Ejercicio3. Escribir un programa que imprima por pantalla los cuadrados
 * (un numero multiplicado por si mismo) de los 40 primeros numeros naturales.
 * PD: utiliza bucle while
 */
$i = 1;
while ($i*$i < 40){
    echo $i*$i.'<br>';
    $i++;
}
?>



