<?php
/*
 * Ejercicio6. Mostrar una tabla en HTML con las tablas de multiplicar del 1 al 10
 */
 
// creamos la tabla
echo '<table border="1">';
for($i = 0; $i<=10; $i++){
    // agregamos la columna
    echo '<tr>';
    /*
     * Hacemos esta verificacion
     * para dejar la primera celda
     * vacia e ir formando
     * la PRIMERA COLUMNA
     * con los numeros del 1 al 10
     */
    if($i != 0){
        /*
         * Vamos llenando la primera columna 
         * con los numeros del 1 al 10
         */
        echo '<td>'.$i.'</td>';
    }
    // Llenamos la tabla
    for($j = 1; $j<=10; $j++){
        /*
         * Hacemos esta verificacion
         * para poder crear un espacio
         * en la primera celda de la tabla.
         */
        if($i==0){
          if($i==0 && $j==1){
            // Agregamos el espacio en la primera celda de la tabla
            echo '<td></td>';
          }
          /*
           * Llenamos el resto de la PRIMERA FILA 
           * con los primeros numeros 
           * del 1 al 10
           */
          echo '<td>'.$j.'</td>';  
        }else{
            // Agregamos la multiplicacion de $i con $j
            echo '<td>'.($i * $j).'</td>';
        }
    }
    // cerramos la columna
    echo '</tr>';
}
// cerramos la tabla
echo '</table>';
/*
echo '<table border="1">';
echo '<tr>';
echo '<td></td>';
echo '<td>1</td>';
echo '<td>2</td>';
echo '</tr>';
echo '<tr>';
echo '<td>1</td>';
echo '<td>1</td>';
echo '<td>2</td>';
echo '</tr>';
echo '<tr>';
echo '<td>2</td>';
echo '<td>2</td>';
echo '<td>4</td>';
echo '</tr>';
echo '</table>';
*/
?>

