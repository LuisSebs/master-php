<?php
/*
 * Ejercicio4. Recoger dos numeros por la URL (parametros get) y hacer todas las 
 * operaciones basicas de una calculadora (suma, resta, multiplicacion y division)
 * de esos dos numeros.
 */
 if(!isset($_GET['numero1'])){
     echo '<p>por favor agrega al final de la url un slash y sun signo de interrogacion <strong>/?</strong>,'
     . ' despues agrega <strong>numero1 = x</strong>, con x el numero que tu quieras seguido de <strong>&</strong>,';
 }
 if(!isset($_GET['numero2'])){
     echo ' despues agrega al final de la url un <strong>numero2 = y</strong>, con y el numero que tu quieras.</p>';
 }
 
 if(isset($_GET['numero1']) && isset($_GET['numero2'])){
     $numero1 = $_GET['numero1'];
     $numero2 = $_GET['numero2'];
     echo $numero1+$numero2.'<br>';
     echo $numero1-$numero2.'<br>';
     echo $numero1*$numero2.'<br>';
     echo $numero1/$numero2.'<br>';
 }
 
 
 

?>

