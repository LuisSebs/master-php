<?php
/*
 * Ejercicio1. Crear dos variables "pais" y y "continente" y mostrar su valor por pantalla (imprimirla).
 * Poner en un comentario que tipo de dato tienen.
 */

// Es de tipo string
$pais = "Mexico";
// Es de tipo string
$contienete = "America";
echo "<h1>$pais</h1>";
echo "<h1>$contienete</h1>";
    
?>

