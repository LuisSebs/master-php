<?php
    /*
     * TIPOS DE DATOS:
     * Entero (int / integer) = 99
     * Coma flotante / decimales (float/double) = 3.45
     * Cadenas (string) = "Hola mundo"
     * Booleano (true/false)
     * null
     * Array (Coleccion de datos)
     * Objetos
     */
     
     // Ejemplos
     $numero = 1;
     $decimal = 2.39;
     $texto = "Hola mundo";
     $verdadero = true;
     $null = null;
     
     
     // El true lo toma como 1
        // echo $verdadero;
        // echo '<br>';
     // El false lo toma como vacio
        // $verdadero = false;
        //echo $verdadero;
        //echo '<br>';
     
     // SABER EL TIPO DE UNA VARIABLE
     echo gettype($numero);
     
     // ARREGLOS
     $arr[] = "Hola";
     $arr[] = "mundo";
     
     // DEBUGEAR
     $hola = "hola";
     // Informacion de la variable
     echo '<h3>Informacion de la variable $hola</h3>';
     var_dump($hola);
     // Informacion de la variable
     echo '<h3>Informacion de la variable $arr</h3>';
     var_dump($arr);
     
     // INCRUSTAR VARIABLES EN CADENAS
     echo '<h3>Incrustar variables en un string</h3>';
     $texto = "mundo";
     echo "Hola $texto";
     // NOTA: Usar comillas dobles ("") es mas lento que usar comillas simples ('')
     // se recomiendo usar comillas simples la mayoria de las veces
     
     // SALTOS DE LINEA: \n
     // NOTA: solo se visualiza en consola
     
     // ESCAPAR COMILLAS DOBLES
     echo '<h3>Escapar comillas dobles</h3>';
     echo "\"Pienso, luego existo.\" Rene Descartes";
     
 
      
?>

