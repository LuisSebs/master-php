<?php
// Operadores aritmeticos
$numero1 = 55;
$numero2 = 33;

// Suma
echo 'Suma: '.($numero1 + $numero2).'<br>';

// Resta
echo 'Resta: '.($numero1 - $numero2).'<br>';

// Multiplicacion
echo 'Multiplicacion: '.($numero1 * $numero2).'<br>';

// Division
echo 'Division: '.($numero1 / $numero2).'<br>'; 

// Modulo
echo 'Modulo: '.($numero1 % $numero2).'<br>';

// Operadores incremento y decremento

echo '<h3>Incremento</h3>';
$year = 2019;
$year++;
echo $year;
echo '<h3>Decremento</h3>';
$year = 2019;
$year--;
echo $year;
echo '<h3>Pre-incremento</h3>';
$year = 2019;
++$year;
echo $year;
echo '<h3>Pre-decremento</h3>';
$year = 2019;
--$year;
echo $year;

// Operadores de asignacion
echo '<h2>Operadores de asignacion</h2>';

echo '<h2>Suma</h2>';
$edad = 55;
$edad+=5;
echo $edad;
echo '<h2>Resta</h2>';
$edad = 55;
$edad-=5;
echo $edad;
echo '<h2>Multiplicacion</h2>';
$edad = 55;
$edad*=5;
echo $edad;
echo '<h2>Division</h2>';
$edad = 55;
$edad/=5;
echo $edad;
?>
