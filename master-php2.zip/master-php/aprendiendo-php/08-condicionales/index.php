<?php
/*
 * // Condicionales
 * if (condicion){
 *  instrucciones
 * }else{
 *  otras instrucciones
 * }
 * 
 * // Operadores de comparacion
 * == igual (mismo valor)
 * === identico (mismo tipo de dato y mismo valor)
 * != diferente (distinto valor)
 * <> diferente (distinto valor)
 * !== no identico (distinto tipo de dato y mismo valor)
 * < menor que
 * > mayor que
 * <= menor o igual que
 * >= mayor o igual que
 * 
 * // OPERADORES LOGICOS
 * &&   AND Y 
 * ||   OR O
 * !    NOT O
 * and  AND Y
 * or   OR O
 */

// EJEMPLO 1
echo '<h3>Ejemplo1</h3>';
$color = 'verde';
if ($color == 'rojo'){
    echo "EL COLOR ES ROJO";
}else{
    echo "EL COLOR NO ES ROJO";
}

// EJEMPLO 2
echo '<h3>Ejemplo2</h3>';
$year = '2019';
if ($year == 2019){
    echo "ESTAMOS EN 2019";
}else{
    echo "NO ESTAMOS EN 2019";
}

// EJEMPLO 3
echo '<h3>Ejemplo3</h3>';
$year = '2019';
if ($year === 2019){
    echo "ESTAMOS EN 2019";
}else{
    echo "NO ESTAMOS EN 2019";
}

// EJEMPLO 4
echo '<h3>Ejemplo4</h3>';
$dia = 3;
if ($dia == 1){
    echo 'Es Lunes';
}elseif ($dia == 2) {
    echo 'Es Martes';
}elseif ($dia == 3) {
    echo 'Es Miercoles';
}elseif ($dia == 4) {
    echo 'Es Jueves';
}elseif ($dia == 5) {
    echo 'Es Viernes';
}elseif ($dia == 6) {
    echo 'Es Sabado';
}else{
    echo 'Es Domingo';
}

// EJEMPLO 5
echo '<h3>Ejemplo5</h3>';
$edad1 = 18;
$edad2 = 64;
$edad_oficial = 70;
if($edad_oficial >= $edad1 && $edad_oficial <= $edad2){
    echo 'Esta en edad de trabajar';
}else{
    echo 'No puede trabajar';
}

// EJEMPLO 6
echo '<h3>Ejemplo6</h3>';
switch($dia){
    case 1:
        echo 'Es Lunes';
        break;
    case 2:
        echo 'Es Martes';
        break;
    case 3:
        echo 'Es Miercoles';
        break;
    case 4:
        echo 'Es Jueves';
        break;
    case 5:
        echo 'Es Viernes';
        break;
    case 6:
        echo 'Es Sabado';
        break;
    case 7:
        echo 'Es Domingo';
        break;
    default:
        echo 'No es ningun dia de la semana';
}

// GOTO
echo '<h3>GO TO</h3>';
// Saltate el resto de codigo y ve a la marca llamada hola_mundo
goto hola_mundo;
echo '1';
echo '2';
echo '3';
echo '4';
// Marca para el go to
hola_mundo:
echo 'Hola mundo';
    
?>


