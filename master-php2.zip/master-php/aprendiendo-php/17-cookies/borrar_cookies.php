<?php
if(isset($_COOKIE['micookie'])){
    // No solo basta con sacarla del arreglo
    unset($_COOKIE['micookie']);
    // Tenemos que caducarla
    setcookie("micookie",'lo que sea',time()-100);
}

// Cambiamos la url y redirigimos al usuario a otra pagina
header('Location:ver_cookies.php');
?>

