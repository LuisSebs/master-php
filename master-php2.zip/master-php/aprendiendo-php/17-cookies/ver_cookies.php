<?php
/*
 * Para mostrar el valor de las cookies, tengo que usar $_COOKIE, una variable superglobal (disponible y accesible
 * desde todas las paginas del proyecto de php), es un array asociativo.
 */

// VER COOKIE 1
if(isset($_COOKIE['micookie'])){
    echo '<h1>'.$_COOKIE['micookie'].'</h1>';
}else{
    echo 'No existe la cookie';
}

// VER COOKIE 2
if(isset($_COOKIE['unyear'])){
    echo '<h1>'.$_COOKIE['unyear'].'</h1>';
}else{
    echo 'No existe la cookie';
}
?>
<a href="crear_cookies.php">Crear las cookies</a>
<a href="borrar_cookies.php">Borrar las cookies</a>

