<?php
    
// Variables
$variable = "Hola mundo";
$numero = 44;
$verdadero = true;
$numero = 77;     

echo '<h1>'.$variable.'</h1>';
echo $numero.'<br>';
$numero = 120;
echo $numero;
?>

