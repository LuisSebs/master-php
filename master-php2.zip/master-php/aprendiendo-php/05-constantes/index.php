<?php
// Constantes
define('nombre','Luis');
// Se llaman sin el $
echo nombre;
echo '<br>';
// Puedes tener una variable y una constante con el mismo nombre
$nombre = 'Sebastian';
echo $nombre;
echo '<br>';
// Concatenamos
echo nombre.$nombre;

// CONSTANTES PREDEFINIDAS
echo '<h3> Constantes predefinidas </h3>';
echo PHP_OS; // Sistema operativo
echo '<br>';
echo __FILE__; // Ruta absoluta del archivo  
echo '<br>';
function holaMundo(){
    // Imprime el nombre de la funcion en la que esta dentro
    echo __FUNCTION__;
}
holaMundo();
?>

