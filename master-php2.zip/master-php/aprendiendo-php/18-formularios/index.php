<!DOCTYPE HTML>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>Formularios PHP y HTML</title>
    </head>
    <body>
        <h1>Formulario</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <!--Texto-->
            <label for="nombre">Nombre:</label>
            <p><input  type="text" name="nombre"/></p>
            <!--Texto-->
            <label for="apellido">Apellido:</label>
            <p><input type="text" name="apellido"/></p>
            <!--Boton-->
            <label for="boton">Apellido:</label>
            <p><input type="button" name="boton"/></p>
            <!--Checkbox-->
            <label for="sexo">Sexo:</label>
            <p>
                Hombre <input type="checkbox" name="sexo" value="hombre"/>
                Mujer <input type="checkbox" name="sexo" value="mujer"/>
            </p>
            <!--Color-->
            <label for="color">Color:</label>
            <p><input type="color" name="color"/></p>
            <!--Fecha-->
            <label for="fecha">Fecha:</label>
            <p><input type="date" name="fecha"/></p>
            <!--Email-->
            <label for="correo">Email:</label>
            <p><input type="email" name="correo"/></p>
            <!--Archivo-->
            <label for="archivo">Archivo:</label>
            <p><input type="file" name="archivo" multiple="multiple"/></p>
            <!--Numero-->
            <label for="numero">Numero:</label>
            <p><input type="number" name="numero"/></p>
            <!--Contraseña-->
            <label for="pass">Contraseña:</label>
            <p><input type="password" name="pass"/></p>
            <!--Radio-->
            <label for="continente">Continente:</label>
            <p>
                America: <input type="radio" name="continente" value="america"/>
                Europa: <input type="radio" name="continente" value="europa"/>
                Asia: <input type="radio" name="continente" value="asia"/>
            </p>
            <!--URL-->
            <label for="web">Pagina web:</label>
            <p><input type="url" name="web"/></p>
            <!--Textarea-->
            <textarea></textarea><br/>
            <!--Select-->
            <select name="peliculas">
                <option value="spiderman">Spiderman</option>
                <option value="batman">Batman</option>
                <option value="the boys">The boys</option>
                <option value="demon slayer">Demon Slayer</option>
            </select>
            <br/>
            
            
            <!--Submit-->
            <p><input type="submit" value="Enviar"/></p>
        </form>
    </body>
</html>
