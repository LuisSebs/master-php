<?php
/*
 * Crear un array con el contenido de la tabla:
 * 
 * ACCION    AVENTURA   DEPORTES
 * 
 * GTA       ASSASINS   FIFA 19
 * COD       CRASH      PES 19
 * PUBG      Prince     MOTO GP 19
 * 
 * Cada fila debe ir en un fichero separado(includes)
 */

$tabla = array(
  "ACCION" => array('GTA','COD','PUBG'),
  "AVENTURA" => array('ASSASINS','CRASH','Prince of persia'),
  "DEPORTES" => array('FIFA 19','PES 19','MOTO GP 19')
);

$categorias = array_keys($tabla);
?>

<table border="1">
    <?php require 'ejercicio5/encabezado.php'?>
    <?php require 'ejercicio5/fila1.php'?>
    <?php require 'ejercicio5/fila2.php'?>
    <?php require 'ejercicio5/fila3.php'?>
</table>

