<?php
/*
 * Escribir un programa con PHP que añada valores a un array mientras que su valor
 * longitud sea menor a 120 y luego mostrarlo por pantalla.
 */

// Arreglo
$arr = array();
for ($i = count($arr);$i<120;$i++){
    array_push($arr, $i);
}
var_dump($arr);


?>
