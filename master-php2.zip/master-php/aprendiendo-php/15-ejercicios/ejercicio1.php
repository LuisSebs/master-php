<?php
/*
 * Ejercicio1. Hacer un programa en PHP que tenga un array con 8 numeros enteros
 * y que haga lo siguiente:
 * - Recorrerlo y mostrarlo
 * - Ordenarlo y mostrarlo
 * - Mostrar su longitud
 * - Buscar un elemento (buscar por el parametro de la URL)
 */

// Funcion que muestra un arreglo
function mostrar($arr){
    $resultado = '';
    foreach($arr as $x){
        $resultado .= $x.'<br>';
    }
    return $resultado;
}

// Creamos el arreglo
$arr = [22,47,73,5,16,15,2,100];
// Recorrer y mostrar el arreglo
echo '<h3> Recorrerlo y mostrarlo </h3>';
echo mostrar($arr);
// Ordenarlo  y mostrarlo
echo '<h3>Ordenarlo y mostrarlo</h3>';
sort($arr);
echo mostrar($arr);
// Mostrar su longitud
echo '<h3>Longitud del arreglo</h3>';
echo count($arr);
// Buscar en el arreglo un elemento
if(isset($_GET['numero'])){
    $busqueda = $_GET['numero'];
    echo '<h3>Buscar en el arreglo el numero '.$busqueda.' </h3>';
    // Obtenemos el indice
    $search = array_search($busqueda,$arr);
    if(gettype($search)=='boolean'){
        echo 'No existe el numero buscado <br>';
    }else{
        echo "<h4>Si existe el numero buscado, en el indice $search</h4>";
    }

    /*
     * NOTA: En el video ponen
     * 
     * if(empty($search)){
     *       echo 'No existe el numero buscado <br>';
     * }else{
     *       echo "<h4>Si existe el numero buscado, en el indice $search</h4>";
     * }
     * 
     * Pero esto esta MAL y lo explicaremos a continuacion: $search almacena el indice del elemento buscado y 
     * en caso de no encontrar el elemento regresa false (recordemos que false en php es considerado
     * como nada, es decir, si haces un echo false veras en pantalla que no aparece nada). Ahora bien ya 
     * sabemos que algunas veces $search almacena un numero y a veces un booleano false. Cuando encuentre que
     * el numero esta en la primera posicion del arreglo entonces nos regresara 0 y dentro de la condicion
     * del if si nosotros pasamos cualquier numero distinto de 0 (esto incluye los negativos) tomara la condicion
     * como verdadera, en caso de que pasemos un 0 lo tomara como falso. Ahora bien, el empty(0) regresara 1
     * que es considerado como true (quiere decir 'En efecto esta vacio'), con cualquier otro numero regresara falso 
     * (que quiere decir 'no es vacio'). De manera que cuando regresemos el indice 0 siempre lo tomara como que 
     * NO EXISTE EL NUMERO EN EL ARREGLO. Para arreglar esto podemos verificar que si $search es un booleano entonces
     * no se encuentra el numero en el arreglo, en caso contrario es un numero y eso quiere decir si se encuentra
     * el numero en el arreglo.
     */
}
?> 

