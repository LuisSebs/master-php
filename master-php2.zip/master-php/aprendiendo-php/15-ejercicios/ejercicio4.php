<?php
/*
 * Ejercicio4. Crear un script en php que tenga 4 variables, una de tipo array,
 * otra de tipo string, otra int y otra booleana y que imprima un mensaje
 * segun el tipo de variable que sea
 */

 $x = [1,2,3,4];
 $y = "Hola";
 $z = 2;
 $w = true;
 $arr  = array();
 array_push($arr,$x,$y,$z,$w);
 foreach($arr as $var){
     if(is_array($var)){
        echo 'Es un arreglo: ';
        var_dump($var);
        echo '<br>';
     }
     if(is_string($var)){
        echo 'Es una cadena: '.$var;
        echo '<br>';
     }
     if(is_int($var)){
        echo 'Es un entero: '.$var;
        echo '<br>';
     }
     if(is_bool($var)){
        echo 'Es un booleano: '.$var;
        echo '<br>';
     }
     
     
 }

         
?>
