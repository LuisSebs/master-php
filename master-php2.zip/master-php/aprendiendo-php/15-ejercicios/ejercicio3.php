<?php
/*
 * Ejercicio3. Programa que compruebe si una variable esta vacia y si esta vacia,
 * rellenarla con texto en minusculas y mostrarlo en mayusculas y negrita.
 */
$variable = null;
if(isset($_GET['variable'])){
    $variable = $_GET['variable'];
}
if(empty($variable)){
    $variable = 'la variable estaba vacia, asi que la rellenamos en mayusculas y negrita';
    $variable = strtoupper($variable);
    echo '<strong>'.$variable.'</strong>';
}else{
    echo '<style>#variable{color: red}</style>';
    echo '<h3>La variable NO esta vacia. Tiene este contenido: <span id="variable"\'>'.$variable.'</span></h3>';
}
?>

