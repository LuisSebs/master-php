<!DOCTYPE HTML>
<html land = "es">
    <head>
        <meta charset="utf-8"/>
        <title>Imprimir por pantalla - Master en PHP</title>
    </head>
    <body>
        <h1>
            Master en PHP 
        </h1>
        
        <?="Bienvenido al curso de php"?>
        
        <?php
            // Titular de la seccion
            echo "<h3>Listado de videojuegos</h3>";
            /*
                Esta es una lista
                de videojuegos
                moderna. El punto
                se usa para concatenar cadenas en php.
            */
            echo "<ul>"
                 ."<li>GTA</li>"
                 ."<li>Fifa</li>"
                 ."<li>Mario Bros</li>"
                 ."</ul>";
            // echo "<br> HOLA HOLA HOLA </br>";
            // Parrafo explicativo
            echo '<p>Esta es toda '.'-'.' lista de videojuegos</p>';
        ?>
    </body>
</html>



