<?php
// Crear carpeta
if(!is_dir('mi_carpeta')){
    // Caso en el que no exista la carpeta
    mkdir('mi_carpeta',0777) or die('No se puede crear la carpeta');
}else{
    // Caso en el que ya exista la carpeta
    echo "Ya existe la carpeta";
}

// Borrar carpeta
// rmdir('mi_carpeta');

// Recorrer el contenido de una carpeta/directorio
echo '<hr><h1>Contenido Carpeta</h1>';
if($gestor = opendir('./mi_carpeta')){
    while(false !== ($archivo = readdir($gestor))){
        if($archivo != '.' && $archivo != '..'){
            echo $archivo."<br/>";   
        }        
    }
}


?>
