<?php
include 'includes/cabecera.php';
/*
 * El require detiene la ejecucion del resto del programa si no se carga bien el fichero:
 * 
 * require 'includessssssssssssss/cabecera.php';
 * 
 * Nota: El mas recomendado es require
 */
?>
        <!--Contenido-->
        <div>
            <h2>Esta es la pagina de inicio</h2>
            <p>Texto de prueba de la pagina de inicio</p>
        </div>
        <?php var_dump($nombre);?>
        
<?php
include 'includes/footer.php';
?>


