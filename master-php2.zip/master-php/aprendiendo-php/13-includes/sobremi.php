<?php
include 'includes/cabecera.php';
?>
        <!--Contenido-->
        <div>
            <h2>Esta es la pagina de sobre mi</h2>
            <p>Texto de prueba de la pagina de inicio</p>
        </div>

<?php
include 'includes/footer.php';
?>

