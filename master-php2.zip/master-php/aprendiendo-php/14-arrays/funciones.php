<?php
$cantantes = ['Ariana Grande','2pac','Drake','MacMiller'];
$numeros = [5,3,2,6,4,1];
// Ordenar alfabeticamente
asort($cantantes);
var_dump($cantantes);
// Ordenar alfabeticamente al reves
arsort($cantantes);
var_dump($cantantes);
// Ordenar alfabeticamente y numericamente
sort($numeros);
var_dump($numeros);
// Añadir elementos
array_push($cantantes,'BAD BUNNY');
var_dump($cantantes); 
// Eliminar elementos 
array_pop($cantantes); // Eliminar desde el final del arreglo
var_dump($cantantes); 
unset($cantantes[3]);
var_dump($cantantes); // Elimina por indice
// Sacar elemento aleatorio
$indice = array_rand($cantantes);
echo $cantantes[$indice];
// Reversa de un arreglo
var_dump(array_reverse($numeros));
// Buscar dentro de un array
$resultado = array_search('2pac',$cantantes);
var_dump($resultado);
// Contar numero de elementos
echo count($cantantes);
?>
