<?php
/*
 * ARRAYS
 */

// EJEMPLOS
$peliculas = array('Batman','Spiderman','El señor de los anillos');
$cantantes = ['2pac','Drake','MacMiller'];
$persona = array(
    'nombre' => 'Luis Sebastian',
    'edad' => 20,
    'altura' => 1.70,
    'instagram' => 'luis_sebastian123'
);
var_dump($peliculas);
var_dump($cantantes);
var_dump($persona);


// Recorrer con for
echo '<h3>Recorrer un arreglo con for</h3>';
echo '<p>Listado de peliculas</p>';
echo '<ul>';
for($i=0;$i<count($peliculas);$i++){
    echo '<li>'.$peliculas[$i].'</li>';
}
echo '</ul>';

// Recorrer con foreach
echo '<h3>Recorrer un arreglo con foreach</h3>';
echo '<p>Listado de cantantes</p>';
echo '<ul>';
foreach ($cantantes as $cantante){
    echo '<li>'.$cantante.'</li>';
}
echo '</ul>';

// Array asociativo
echo '<h3>Arrays asociativos</h3>';
echo $persona['nombre'].' tiene '.$persona['edad'].' años, mide '.$persona['altura'].'m y su instagram es '.$persona['instagram'];

// Arrays multidimensionales
echo '<h3>Arrays multidimensionales</h3>';
$amigos = array(
    array(
       'nombre' => 'martin',
        'altura' => '1.80'
    ),
    array(
        'nombre' => 'stephanie',
        'altura' => '1.64'
    ),
    array(
        'nombre' => 'valeria',
        'altura' => 1.53
    )
);
var_dump($amigos);
echo $amigos[1]['nombre'];

?>
