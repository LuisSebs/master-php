<?php
// Variables superglobales

// Variables de servidor
echo '<h1>';
echo $_SERVER['SERVER_ADDR']; // Regresa la direccion IP de mi servidor
echo '</h1>';

echo '<h1>';
echo $_SERVER['SERVER_NAME']; // Regresa el nombre del dominio del servidor
echo '</h1>';

echo '<h1>';
echo $_SERVER['SERVER_SOFTWARE']; // Regresa el software que se esta utilizando
echo '</h1>';

echo '<h1>';
echo $_SERVER['HTTP_USER_AGENT']; // Regresa desde donde esta accediendo el usuario
echo '</h1>';

echo '<h1>';
echo $_SERVER['REMOTE_ADDR']; // Regresa la IP remota del usuario
echo '</h1>';
?>
