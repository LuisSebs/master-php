<!DOCTYPE HTML>
<html lang = "es">
    <head>
        <meta charset = 'utf-8'>
        <title>Formulario en PHP</title>
    </head>
    <body>
        <h1>Formulario en PHP con GET (Se muestran en la URL)</h1>
        <form method="GET" action="recibir.php">
            <p>
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre"/> 
            </p>
           
            <p>
                <label for="apellido">Apellido</label>
                <input type="text" name="apellido"/> 
            </p>
            <input type="submit" value="Enviar por GET"/>
        </form>
        
        <h1>Formulario en PHP con POST (no se muestran)</h1>
        <form method="POST" action="recibir.php">
            <p>
                <label for="animal">Animal</label>
                <input type="text" name="animal"/> 
            </p>
           
            <p>
                <label for="fruta">Fruta</label>
                <input type="text" name="fruta"/> 
            </p>
            <input type="submit" value="Enviar por POST"/>
        </form>
    </body>
</html>



<?php

?>

