<?php
    echo '<h3>Mostramos el contenido de GET';
    var_dump($_GET);
    echo '<h3>Mostramos el nombre</h3>';
    echo $_GET['nombre'];
    echo '<h3>Mostramos el apellido</h3>';
    echo $_GET['apellido'];
    /*
     * NOTA: Podemos modificar/agregar los valores que aparecen en la URL y nos lo mostrara
    */
     echo '<h3>Mostramos el contenido de POST';
    var_dump($_POST);
    echo '<h3>Mostramos el nombre</h3>';
    echo $_POST['animal'];
    echo '<h3>Mostramos el apellido</h3>';
    echo $_POST['fruta'];
?>
