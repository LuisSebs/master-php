<?php
// BUCLE WHILE
$numero = 0;
while($numero <= 10){
    echo $numero;
    echo '<br>';
    $numero++;
}

// EJEMPLO WHILE
echo '<h1>Ejemplo while</h1>';
// Verificamos que exista el indice 'numero' en GET. Para eso se usa el metodo isset()
if(isset($_GET['numero'])){
    // Hacemos un casteo para convertir un string a un entero
    $numero = (int) $_GET['numero'];
}else{
    $numero = 1;
}

// Mostramos el contenido del numero
var_dump($numero);

echo '<h3>Tabla de multiplicar del numero '.$numero.'</h3>';
$i = 1;
while ($i < 11){
    echo "$numero x $i = ".($numero * $i);
    echo '<br>'; 
    $i++;
    
}

//  EJEMPLO DO WHILE
echo '<h1>Ejemplo do while</h1>';
$edad = 17;
$contador = 1;
do{
    echo "Tienes accceso al local privado $contador <br>";
    $contador++;
}while($edad >=18 && $contador <= 10);


?>
