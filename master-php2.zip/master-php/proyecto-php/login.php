<?php
// Iniciar la sesion y la conexcion a la db
require_once 'includes/conexion.php';

// Recoger datos del formulario
if(isset($_POST['email']) && isset($_POST['password'])){
    
    // Borrar error antiguo
    if(isset($_SESSION['error_login'])){
        // Si algo falla enviar una sesion con el fallo
        unset($_SESSION['error_login']);
    }
    
    // Recoger datos del formulario
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    echo $email.'<br>';
    echo $password.'<br>';
    
    // Consulta para comprobar las credenciales del usuario
    $sql = "SELECT * FROM usuarios WHERE email = '$email';";
    $login = mysqli_query($db, $sql);
    
    if($login && mysqli_num_rows($login) == 1){
        
        // Consulta para comprobar las credenciales del usuario
        $usuario = mysqli_fetch_assoc($login);
        
        // Comprobar la contraseña
        $verify = password_verify($password, $usuario['password']);
        
        if($verify){
            // Utilizar una sesion para guardar los datos del usuario logueado
            $_SESSION['usuario'] = $usuario;
        }else{
            $_SESSION['error_login'] = "Login incorrecto!!";
        }
    }else {
        // Mensaje de error
        $_SESSION['error_login'] = "Login incorrecto!!";
    }
    
}

// Redirigir al index.php
header('Location: index.php');
