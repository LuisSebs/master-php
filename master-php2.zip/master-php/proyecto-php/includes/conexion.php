<?php

// Conexion

$servidor = 'localhost';
$usuario = 'root';
$password = '';
$basededatos = 'blog_master';
$db = mysqli_connect($servidor,$usuario,$password,$basededatos);


// Iniciar la sesion
if(!isset($_SESSION)){
    session_start();
}
