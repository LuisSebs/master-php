
    <div class="clearfix"></div>
</div> <!--fin contenedor-->
<!-- PIE DE PAGINA -->
<footer id='pie'>
    <p>Desarrollado por Luis Sebastian &copy; 2023</p>
</footer>
    </body>
</html>